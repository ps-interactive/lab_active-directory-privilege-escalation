using System;
using System.Web.UI;
using System.Web.Security;

public partial class index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void LoginButton_Click(object sender, EventArgs e)
    {
        string username = UsernameTextBox.Text.Trim();
        string password = PasswordTextBox.Text;

        // Simple hardcoded lab credentials
        if (username == "admin" && password == "CyberNinjaTactics!")
        {
            FormsAuthentication.SetAuthCookie(username, false);
            Response.Redirect("upload.aspx");
        }
        else
        {
            ErrorLabel.Text = "Invalid username or password.";
            ErrorLabel.CssClass = "error-show";
        }
    }
}


