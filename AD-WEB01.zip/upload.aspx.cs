using System;
using System.IO;

public partial class upload : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void UploadButton_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            try
            {
                string savePath = Server.MapPath("~/uploads/") + FileUpload1.FileName;
                FileUpload1.SaveAs(savePath);
                ErrorLabel.Text = "Upload successful!";
                ErrorLabel.CssClass = "error-show";
            }
            catch (Exception ex)
            {
                ErrorLabel.Text = "Upload failed: " + ex.Message;
                ErrorLabel.CssClass = "error-show";
            }
        }
        else
        {
            ErrorLabel.Text = "No file selected.";
            ErrorLabel.CssClass = "error-show";
        }
    }
}
